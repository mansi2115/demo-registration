package com.com.demo.registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterationApplicationTests {

	@Test
	void contextLoads() {
	}

}
