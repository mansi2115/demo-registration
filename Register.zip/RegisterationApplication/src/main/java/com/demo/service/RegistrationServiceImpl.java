package com.demo.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.RegistrationDAO;
import com.demo.entities.User;

@Transactional
@Service
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	RegistrationDAO registrationDAO;
	
	//saving user details into database
	@Override
	public int saveUserDetails(User user) {
		try {
			
			User userDetails= registrationDAO.save(user);
			return userDetails.getUserId();
			
		}catch(Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	
	}

	//fetching user details from database based on user's email
	@Override
	public User getUserByEmail(String email) {
		User userDetails = null;
		try {
			
			userDetails = registrationDAO.findByEmail(email); 
			
		}catch(Exception ex) {
			ex.printStackTrace();

			
		}
		return userDetails;
	}

}
