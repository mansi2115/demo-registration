package com.demo.service;

import com.demo.entities.User;

public interface RegistrationService {
	
	int saveUserDetails(User user);
	
	User getUserByEmail(String email);
	

}
