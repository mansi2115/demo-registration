package com.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.demo.entities.User;
import com.demo.service.RegistrationService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class RegistrationController {
	
	@Autowired
	RegistrationService registrationService;


	@PostMapping(value = "/save")
	public String saveUser(@RequestBody User user) {
		
		int userId = registrationService.saveUserDetails(user);
		if(userId>0) {
			return "Your registration successful.";
			
		}else {
			return "Something went wrong. Please try again...";
		}
		
	}
	
	@GetMapping(value = "/getUser/{email}")
	public  String getUser(@PathVariable final String email) {
		ObjectMapper mapper = new ObjectMapper();
		String userJson = null;
		try {
			System.out.println("Email "+email);
		User user = registrationService.getUserByEmail(email);
		
		if(user!= null) {
			 userJson = mapper.writeValueAsString(user);
			
		}else {
			userJson = "User Not Found";
		}
		}catch(Exception ex) {
			ex.printStackTrace();
			userJson = "Something went wrong. Please try again...";
		}
		return userJson;
	}

}
